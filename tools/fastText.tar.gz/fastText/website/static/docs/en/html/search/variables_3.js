var searchData=
[
  ['data_5f',['data_',['../classfasttext_1_1Matrix.html#a3a63d6e3e3db63e5f756bbc4692a46ae',1,'fasttext::Matrix::data_()'],['../classfasttext_1_1Vector.html#ab177f24ed7071636dcd17e90a746dd2e',1,'fasttext::Vector::data_()']]],
  ['dict_5f',['dict_',['../classfasttext_1_1FastText.html#a2f5648d532a7ff4f46ac425197082422',1,'fasttext::FastText']]],
  ['dim',['dim',['../classfasttext_1_1Args.html#a76595eefd3fcfd980d1d4d2fa57dbaf3',1,'fasttext::Args']]],
  ['dim_5f',['dim_',['../classfasttext_1_1ProductQuantizer.html#afdeec3948e983b1f3e1e36292153e300',1,'fasttext::ProductQuantizer']]],
  ['dsub',['dsub',['../classfasttext_1_1Args.html#a7ee03404aa6c513ee8cc4b07715977c5',1,'fasttext::Args']]],
  ['dsub_5f',['dsub_',['../classfasttext_1_1ProductQuantizer.html#a9221f241be27487c671bbbba7a84b389',1,'fasttext::ProductQuantizer']]]
];
