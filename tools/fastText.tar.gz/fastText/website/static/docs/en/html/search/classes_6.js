var searchData=
[
  ['productquantizer',['ProductQuantizer',['../classfasttext_1_1ProductQuantizer.html',1,'fasttext']]]
];
