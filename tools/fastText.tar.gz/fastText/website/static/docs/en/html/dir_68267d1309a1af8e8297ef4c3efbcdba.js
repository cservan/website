var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "args.cc", "args_8cc.html", null ],
    [ "args.h", "args_8h.html", "args_8h" ],
    [ "dictionary.cc", "dictionary_8cc.html", null ],
    [ "dictionary.h", "dictionary_8h.html", "dictionary_8h" ],
    [ "fasttext.cc", "fasttext_8cc.html", null ],
    [ "fasttext.h", "fasttext_8h.html", "fasttext_8h" ],
    [ "main.cc", "main_8cc.html", "main_8cc" ],
    [ "matrix.cc", "matrix_8cc.html", null ],
    [ "matrix.h", "matrix_8h.html", [
      [ "Matrix", "classfasttext_1_1Matrix.html", "classfasttext_1_1Matrix" ]
    ] ],
    [ "model.cc", "model_8cc.html", null ],
    [ "model.h", "model_8h.html", "model_8h" ],
    [ "productquantizer.cc", "productquantizer_8cc.html", "productquantizer_8cc" ],
    [ "productquantizer.h", "productquantizer_8h.html", [
      [ "ProductQuantizer", "classfasttext_1_1ProductQuantizer.html", "classfasttext_1_1ProductQuantizer" ]
    ] ],
    [ "qmatrix.cc", "qmatrix_8cc.html", null ],
    [ "qmatrix.h", "qmatrix_8h.html", [
      [ "QMatrix", "classfasttext_1_1QMatrix.html", "classfasttext_1_1QMatrix" ]
    ] ],
    [ "real.h", "real_8h.html", "real_8h" ],
    [ "utils.cc", "utils_8cc.html", "utils_8cc" ],
    [ "utils.h", "utils_8h.html", "utils_8h" ],
    [ "vector.cc", "vector_8cc.html", "vector_8cc" ],
    [ "vector.h", "vector_8h.html", "vector_8h" ]
];