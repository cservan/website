var searchData=
[
  ['entry_5ftype',['entry_type',['../namespacefasttext.html#a532eedeee97e8d66a96b519d165f4eb7',1,'fasttext']]]
];
