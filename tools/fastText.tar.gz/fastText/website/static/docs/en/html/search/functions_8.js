var searchData=
[
  ['initlog',['initLog',['../classfasttext_1_1Model.html#abf8bafb8fc35c220bf961893bf459c07',1,'fasttext::Model']]],
  ['initngrams',['initNgrams',['../classfasttext_1_1Dictionary.html#ab415b87adacc7d1570f8e2f630fe45c1',1,'fasttext::Dictionary']]],
  ['initsigmoid',['initSigmoid',['../classfasttext_1_1Model.html#ab64ec566b2fc836050ef178ec11df780',1,'fasttext::Model']]],
  ['inittablediscard',['initTableDiscard',['../classfasttext_1_1Dictionary.html#aaa2d7d0ccde56223a3088594651e782e',1,'fasttext::Dictionary']]],
  ['inittablenegatives',['initTableNegatives',['../classfasttext_1_1Model.html#a03859cabcddafddfdb7e6d8862e2ae6c',1,'fasttext::Model']]]
];
